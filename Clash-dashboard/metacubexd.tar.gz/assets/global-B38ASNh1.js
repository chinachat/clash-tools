import{W as a,a$ as m}from"./index-B2UtOO5P.js";const s=o=>a(o).locale(m()).fromNow();export{s as f};
