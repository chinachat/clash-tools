import{d as t,bt as r}from"./index-BsECLATv.js";const o=({children:e})=>t(r,{get children(){return[e," - MetaCubeXD"]}});export{o as D};
